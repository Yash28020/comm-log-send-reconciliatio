"""
Independent cross-check of target_base, built without SQL.

Why this exists: the SQL query in query.sql and this script implement the same
business rules (eligibility gate, retry-chain rollup, standalone exception) via
two structurally different mechanisms -- a recursive CTE vs. iterative graph
traversal in pandas. If both agree, that's much stronger evidence the number is
right than either one passing on its own; a bug shared by both implementations
is unlikely if they were built independently.

Usage:
    python3 validate.py [--db data/comm_log.db] [--merchant 501]
                         [--start 2026-10-01] [--end 2026-11-01]

Exits non-zero (and prints a diff) if this script's answer disagrees with
running query.sql through sqlite3, so this can be dropped into CI.
"""

import argparse
import sqlite3
import subprocess
import sys
from pathlib import Path

import pandas as pd

FINALIZED_CREATION_STATUSES = {"approved", "aborted", "resumed", "stopped"}


def find_root(campaign_id: int, parent_of: dict[int, int | None]) -> tuple[int, int]:
    """Walk parent_id links to the ultimate root ancestor.

    Returns (root_id, chain_length). Guards against cycles (which shouldn't
    exist in well-formed data, but a real production dataset can surprise
    you) by capping traversal at len(parent_of) hops and raising if exceeded.
    """
    visited = []
    current = campaign_id
    max_hops = len(parent_of) + 1
    while True:
        visited.append(current)
        if len(visited) > max_hops:
            raise ValueError(
                f"Cycle detected in campaign.parent_id chain starting at "
                f"{campaign_id}: {visited}"
            )
        parent = parent_of.get(current)
        if parent is None:
            return current, len(visited)
        current = parent


def compute_target_base(
    campaign: pd.DataFrame,
    comm_log: pd.DataFrame,
    merchant_id: int,
    start: str,
    end: str,
    name_filter: str = "Diwali",
) -> tuple[int, pd.DataFrame]:
    """Returns (target_base, per_chain_breakdown)."""

    camp = campaign[campaign["merchant_id"] == merchant_id].copy()

    # Step 1: eligibility gate.
    eligible_mask = (
        camp["creation_status"].isin(FINALIZED_CREATION_STATUSES)
        & (camp["processing_status"] == "processed")
    )
    eligible = camp[eligible_mask].copy()
    dropped = camp[~eligible_mask]
    if len(dropped):
        print(
            f"[validate] excluding {len(dropped)} non-finalized campaign(s): "
            f"{dropped['id'].tolist()} (creation_status="
            f"{dropped['creation_status'].tolist()})"
        )

    parent_of = dict(
        zip(eligible["id"], eligible["parent_id"].where(eligible["parent_id"].notna(), None))
    )
    # normalize NaN -> None, and ints stay ints
    parent_of = {
        k: (int(v) if v is not None and not pd.isna(v) else None)
        for k, v in parent_of.items()
    }

    roots, chain_len = {}, {}
    for cid in eligible["id"]:
        root_id, length = find_root(cid, parent_of)
        roots[cid] = root_id
        chain_len[root_id] = length if length > chain_len.get(root_id, 0) else chain_len.get(root_id, length)

    # chain_len as computed above is wrong for chains >2 deep (it just tracks
    # the deepest single walk); what we actually need is the count of DISTINCT
    # eligible campaign ids per root. Recompute cleanly:
    root_of_series = pd.Series(roots, name="root_id")
    campaigns_per_root = root_of_series.value_counts()  # index: root_id, value: n campaigns in chain

    log = comm_log[
        (comm_log["merchant_id"] == merchant_id)
        & (comm_log["communication_type"].astype(str) == "2")
        & (comm_log["sent_time"] >= start)
        & (comm_log["sent_time"] < end)
    ].copy()

    # Filter to campaigns whose ROOT name matches (a retry like "...Retry A"
    # belongs to the same reported communication as its Diwali-named root,
    # even if the retry's own name is generic) -- matches query.sql's logic
    # of joining the log row's chain root back to campaign.name.
    log = log[log["communication_id"].isin(roots.keys())].copy()
    log["root_id"] = log["communication_id"].map(roots)
    root_names = eligible.set_index("id")["name"]
    log = log[log["root_id"].map(root_names).str.contains(name_filter, case=False, na=False)]

    # Iterate per root explicitly (rather than groupby().apply, which has
    # inconsistent behavior across pandas versions re: access to the group
    # key when include_groups=False) -- this is also just easier to step
    # through in a debugger than a groupby callback.
    rows = []
    for root_id, group in log.groupby("root_id"):
        n_campaigns = int(campaigns_per_root.get(root_id, 1))
        if n_campaigns == 1:
            qualifying = len(group)  # standalone: every send is its own event
        else:
            qualifying = group["customer_id"].nunique()  # chain: distinct customers only
        rows.append(
            {
                "root_id": root_id,
                "root_name": root_names.get(root_id),
                "n_campaigns": n_campaigns,
                "qualifying_sends": qualifying,
            }
        )
    columns = ["root_id", "root_name", "n_campaigns", "qualifying_sends"]
    breakdown = (
        pd.DataFrame(rows, columns=columns).sort_values("root_id").reset_index(drop=True)
        if rows
        else pd.DataFrame(columns=columns)
    )

    total = int(breakdown["qualifying_sends"].sum()) if len(breakdown) else 0
    return total, breakdown


def run_sql_version(db_path: Path) -> int:
    sql = (Path(__file__).parent / "query.sql").read_text()
    # strip the commented-out debug SELECT at the bottom so only the real
    # final SELECT executes
    conn = sqlite3.connect(db_path)
    try:
        cur = conn.execute(sql)
        return cur.fetchone()[0]
    finally:
        conn.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default="data/comm_log.db")
    ap.add_argument("--campaign-csv", default="data/campaign.csv")
    ap.add_argument("--log-csv", default="data/communication_log.csv")
    ap.add_argument("--merchant", type=int, default=501)
    ap.add_argument("--start", default="2026-10-01")
    ap.add_argument("--end", default="2026-11-01")
    args = ap.parse_args()

    campaign = pd.read_csv(args.campaign_csv)
    comm_log = pd.read_csv(args.log_csv)

    pandas_result, breakdown = compute_target_base(
        campaign, comm_log, args.merchant, args.start, args.end
    )

    print("\nPer-chain breakdown (pandas, independent implementation):")
    print(breakdown.to_string(index=False))
    print(f"\n[validate] pandas implementation -> target_base = {pandas_result}")

    sql_result = run_sql_version(Path(args.db))
    print(f"[validate] SQL implementation      -> target_base = {sql_result}")

    if pandas_result != sql_result:
        print(
            f"\n MISMATCH: pandas={pandas_result} vs sql={sql_result}. "
            "The two independent implementations disagree -- do not trust "
            "either number until this is resolved.",
            file=sys.stderr,
        )
        sys.exit(1)

    print(f"\n Both independent implementations agree: target_base = {sql_result}")


if __name__ == "__main__":
    main()
